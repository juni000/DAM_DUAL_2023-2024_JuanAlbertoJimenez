package gestionAulas;

public class Docencia {
	private int magnitud = 36; //tamaño en m2
	private int usuarios = 0; //número de alumnos
	public String codigo = "";
	public static int numeroAulas = 0;
	
	Docencia (int alumnos){
		this.usuarios = alumnos;
		this.codigo = String.format("D%04d", Docencia.numeroAulas);
		Docencia.numeroAulas++;
    }
    
	public int getMagnitud() {
		 return magnitud;
	}
	 
	public void setMagnitud(int magnitud) {
		 this.magnitud = magnitud;
	}
	 
	public int getUsuarios() {
		 return usuarios;
	}
	 
	 public void setUsuarios(int usuarios) {
		 this.usuarios = usuarios;
	 }
	 
	 public boolean limiteCapacidad() {
		 if (magnitud/usuarios >= 1) {
			 return false;
		 } else return true;
	 }
	 
	 public void avisoExcesoCapacidad() {
	   if (this.limiteCapacidad()) 
		System.out.println("***Cuidado, ha superado la capacidad máxima del aula DOCENCIA ***");
     }
	 
	 public void imprimirInfo() {
		 System.out.println("Aula Docencia [" + codigo + "] => Magnitud: "
				+ magnitud + " => Usuarios: " + usuarios);
	 }
	
}
