package calcular_Promedio;

public class Promedio {

	public static void main(String[] args) {
		int nota1 = 0, nota2 = 0, nota3 = 0;
		int promedio = 0;
		nota1 = 1;
		nota2 =9;
		nota3= 5;
		promedio = (nota1 + nota2 + nota3) / 3;
		System.out.println("Tu promedio es = " + promedio);	
	}

}
