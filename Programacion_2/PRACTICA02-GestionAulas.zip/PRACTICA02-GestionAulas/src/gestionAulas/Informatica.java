package gestionAulas;

public class Informatica {

	private int magnitud = 24; //tamaño en m2
	private int usuarios = 0; //número de alumnos
	private int pcs = 0;
	public String codigo = "";
	public static int numeroAulas = 0;
	
	Informatica (int alumnos){
		this.usuarios = alumnos;
		this.pcs = (int)(this.magnitud/2);
		this.codigo = String.format("I%04d", Informatica.numeroAulas);
		Informatica.numeroAulas++;
    }
	Informatica (int alumnos, int pcs){
		this.usuarios = alumnos;
		this.pcs = pcs;
		this.codigo = String.format("I%04d", Informatica.numeroAulas);
		Informatica.numeroAulas++;
    }
	public int getMagnitud() {
		 return magnitud;
	}
	 
	public void setMagnitud(int magnitud) {
		 this.magnitud = magnitud;
	}
	 
	public int getUsuarios() {
		 return usuarios;
	}
	 
	 public void setUsuarios(int usuarios) {
		 this.usuarios = usuarios;
	 }
	 
	 public boolean limiteCapacidad() {
		 if (pcs >= usuarios) {
			 return false;
		 }
		 else return true;
	 }
	 
	 public void avisoExcesoCapacidad() {
	   if (this.limiteCapacidad()) 
		System.out.println("***Cuidado, ha superado la capacidad máxima del aula INFORMÁTICA ***");
     }
	 
	 public void imprimirInfo() {
		 System.out.println("Aula Informática [" + codigo + "] => Magnitud: " 
		 		+ magnitud + " => Usuarios: " + usuarios + " => PCs: " + pcs);
	 }
}