package promedio_3_notas;

public class Promedio_3_notas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
