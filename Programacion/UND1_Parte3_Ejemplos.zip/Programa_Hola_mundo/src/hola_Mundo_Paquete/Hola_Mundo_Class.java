package hola_Mundo_Paquete;

public class Hola_Mundo_Class {
	
	public static void main(String[] args) {
		/*Programa de Hola Mundo*/
		System.out.println("Hola Mundo");
		System.out.println("Adios Mundo");
		
	}

}